# c.execute("Drop Table Pizza")
# c.execute("Drop Table Canceled_Pizza")
# c.execute("Drop table Served_Pizza")
# c.execute("Drop table Pending_Pizza")